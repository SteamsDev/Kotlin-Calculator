
rootProject.name = "Kotculator"

